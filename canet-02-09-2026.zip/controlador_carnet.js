   /* =========================================
           CONFIGURACIÓN DE SISTEMA (EDITAR AQUÍ)
           ========================================= */
        const SYS_CONFIG = {
            admin_user: 'admin',       // Usuario para Administrador
            admin_pass: 'Admin2026*',  // Contraseña para Administrador
            operador_user: 'usuario',  // Usuario para Operador
            operador_pass: 'User2026'  // Contraseña para Operador
        };

        /* =========================================
           CARPETA: /js/app.js (Controlador Principal)
           ========================================= */
        const app = {
            state: {
                role: null, // 'admin' or 'operador'
                images: { foto: null, firma: null, huella: null }
            },

            init: function() {
                this.loadSystemImages(); 
                this.setDefaultDates();
                // Preparar UI Login por defecto
                this.setLoginRole('admin');
            },

            setDefaultDates: function() {
                const today = new Date();
                const nextYear = new Date();
                nextYear.setFullYear(today.getFullYear() + 1);
                
                document.getElementById('f_fecha_emision').valueAsDate = today;
                document.getElementById('f_fecha_venc').valueAsDate = nextYear;
            },

            // Interfaz de Login
            setLoginRole: function(role) {
                document.getElementById('login-role').value = role;
                const btnAdmin = document.getElementById('btn-role-admin');
                const btnOp = document.getElementById('btn-role-operador');
                
                if(role === 'admin') {
                    btnAdmin.className = "px-3 py-1 text-sm border border-institucional text-institucional font-bold rounded bg-blue-50 transition";
                    btnOp.className = "px-3 py-1 text-sm border border-gray-300 text-gray-600 font-bold rounded bg-gray-100 hover:bg-gray-200 transition";
                    document.getElementById('login-user').value = SYS_CONFIG.admin_user;
                } else {
                    btnOp.className = "px-3 py-1 text-sm border border-institucional text-institucional font-bold rounded bg-blue-50 transition";
                    btnAdmin.className = "px-3 py-1 text-sm border border-gray-300 text-gray-600 font-bold rounded bg-gray-100 hover:bg-gray-200 transition";
                    document.getElementById('login-user').value = SYS_CONFIG.operador_user;
                }
                document.getElementById('login-pass').value = '';
            },

            login: function() {
                const role = document.getElementById('login-role').value;
                const user = document.getElementById('login-user').value;
                const pass = document.getElementById('login-pass').value;
                
                if (role === 'admin' && user === SYS_CONFIG.admin_user && pass === SYS_CONFIG.admin_pass) {
                    this.state.role = 'admin';
                    document.getElementById('btn-settings').classList.remove('hidden');
                    this.completeLogin('Administrador Sistema');
                } else if (role === 'operador' && user === SYS_CONFIG.operador_user && pass === SYS_CONFIG.operador_pass) {
                    this.state.role = 'operador';
                    document.getElementById('btn-settings').classList.add('hidden');
                    this.completeLogin('Operador de Registro');
                } else {
                    alert('Credenciales incorrectas. Verifique usuario y contraseña.');
                }
            },

            completeLogin: function(roleName) {
                document.getElementById('view-login').classList.add('hidden');
                document.getElementById('view-main').classList.remove('hidden-view');
                document.getElementById('user-display').innerText = roleName;
                this.changeView('form');
            },

            logout: function() {
                this.state.role = null;
                document.getElementById('view-main').classList.add('hidden-view');
                document.getElementById('view-login').classList.remove('hidden');
                document.getElementById('login-pass').value = '';
            },

            // Navegación
            changeView: function(panelId) {
                document.querySelectorAll('aside button').forEach(btn => {
                    btn.classList.remove('bg-blue-100', 'text-institucional', 'border-blue-200');
                    btn.classList.add('text-gray-600', 'border-transparent');
                });

                document.getElementById('panel-form').classList.add('hidden-view');
                document.getElementById('panel-preview-carnet').classList.add('hidden-view');
                document.getElementById('panel-preview-carta').classList.add('hidden-view');
                document.getElementById('panel-settings').classList.add('hidden-view');

                document.body.className = "text-gray-800"; 
                
                if (panelId === 'form') {
                    document.getElementById('panel-form').classList.remove('hidden-view');
                    const nav = document.getElementById('nav-form');
                    nav.classList.add('bg-blue-100', 'text-institucional', 'border-blue-200');
                    nav.classList.remove('text-gray-600', 'border-transparent');
                } else if (panelId === 'preview-carnet') {
                    document.getElementById('panel-preview-carnet').classList.remove('hidden-view');
                    const nav = document.getElementById('nav-preview');
                    nav.classList.add('bg-blue-100', 'text-institucional', 'border-blue-200');
                    nav.classList.remove('text-gray-600', 'border-transparent');
                    document.body.classList.add('printing-carnet');
                } else if (panelId === 'preview-carta') {
                    document.getElementById('panel-preview-carta').classList.remove('hidden-view');
                    const nav = document.getElementById('nav-letter');
                    nav.classList.add('bg-blue-100', 'text-institucional', 'border-blue-200');
                    nav.classList.remove('text-gray-600', 'border-transparent');
                    document.body.classList.add('printing-carta');
                } else if (panelId === 'settings') {
                    document.getElementById('panel-settings').classList.remove('hidden-view');
                }
            },

            // Gestión de Imágenes (Menor)
            handleImageUpload: function(inputElement, type) {

    if (!inputElement.files || !inputElement.files[0]) {
        return;
    }

    const reader = new FileReader();

    reader.onload = function(e) {

        const imagen = e.target.result;

        // Guardar temporalmente
        app.state.images[type] = imagen;


        // ==============================
        // PREVIEW EN EL FORMULARIO
        // ==============================

        const previewImg =
            document.getElementById(`preview_img_${type}`);

        const icon =
            document.getElementById(`icon_${type}`);

        if (previewImg) {
            previewImg.src = imagen;
            previewImg.classList.remove('hidden');
        }

        if (icon) {
            icon.classList.add('hidden');
        }


        // ==============================
        // FOTO DEL MENOR
        // ==============================

        if (type === 'foto') {

            const fotoFrente =
                document.getElementById('render_foto');

            const fotoVuelto =
                document.getElementById('render_foto_v');

            if (fotoFrente) {
                fotoFrente.src = imagen;
            }

            if (fotoVuelto) {
                fotoVuelto.src = imagen;
            }
        }


        // ==============================
        // FIRMA DEL MENOR
        // ==============================

        else if (type === 'firma') {

            const firma =
                document.getElementById('render_firma_menor_v');

            if (firma) {

                firma.src = imagen;

                firma.classList.remove('hidden');
            }
        }


        // ==============================
        // HUELLA
        // ==============================

        else if (type === 'huella') {

            const huella =
                document.getElementById('render_huella_v');

            if (huella) {

                huella.src = imagen;

                huella.classList.remove('hidden');
            }
        }
    };


    reader.readAsDataURL(
        inputElement.files[0]
    );
},

            // Gestión de Imágenes (Admin / Sistema)
            saveSystemImage: function(inputElement, key) {
                if (inputElement.files && inputElement.files[0]) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        const base64Data = e.target.result;
                        try {
                            localStorage.setItem(key, base64Data);
                            app.applySystemImage(key, base64Data);
                        } catch (e) {
                            alert("Error al guardar imagen en navegador. Archivo muy pesado.");
                        }
                    }
                    reader.readAsDataURL(inputElement.files[0]);
                }
            },

            applySystemImage: function(key, data) {
                const preview = document.getElementById(`preview_${key}`);
                if (preview) { preview.src = data; preview.classList.remove('hidden'); }
                
                // Mapeo exhaustivo a IDs en el carnet/carta
                const map = {
                    'sys_logo_izq': ['render_logo_izq', 'c_logo_alcaldia'],
                    'sys_logo_der': ['render_logo_der', 'c_escudo'],
                    'sys_escudo_agua': ['render_escudo_agua'],
                    'sys_firma_alcalde': ['render_firma_alcalde'],
                    'sys_sello_alcalde': ['render_sello_alcalde'],
                    'sys_firma_jefe': ['render_firma_jefe'],
                    'sys_sello_jefe': ['render_sello_jefe']
                };

                if (map[key]) {
                    map[key].forEach(elementId => {
                        const el = document.getElementById(elementId);
                        if (el) {
                            el.src = data;
                            el.classList.remove('hidden', 'opacity-0');
                        }
                    });
                }
            },

            loadSystemImages: function() {
                const keys = ['sys_logo_izq', 'sys_logo_der', 'sys_escudo_agua', 'sys_firma_alcalde', 'sys_sello_alcalde', 'sys_firma_jefe', 'sys_sello_jefe'];
                keys.forEach(key => {
                    const data = localStorage.getItem(key);
                    if (data) { this.applySystemImage(key, data); }
                });
            },

            // Lógica Central: Pasar datos del form a las plantillas
            saveDataAndPreview: function() {

    // ==========================================
    // FUNCIONES AUXILIARES
    // ==========================================

    const getVal = (id) => {

        const elemento = document.getElementById(id);

        if (!elemento) {
            console.warn("No existe el campo:", id);
            return '---';
        }

        return elemento.value.trim() || '---';
    };


    const setText = (id, valor) => {

        const elemento = document.getElementById(id);

        if (elemento) {
            elemento.innerText = valor;
        } else {
            console.warn("No existe el elemento de salida:", id);
        }
    };


    const formatDate = (id) => {

        const elemento = document.getElementById(id);

        if (!elemento || !elemento.value) {
            return '---';
        }

        const partes = elemento.value.split('-');

        if (partes.length === 3) {
            return `${partes[2]}/${partes[1]}/${partes[0]}`;
        }

        return elemento.value;
    };


    // ==========================================
    // FRENTE DEL CARNET
    // ==========================================

    setText(
        'r_carnet',
        getVal('f_carnet_num')
    );

    setText(
        'r_nombres',
        getVal('f_nombres').toUpperCase()
    );

    setText(
        'r_apellidos',
        getVal('f_apellidos').toUpperCase()
    );

    setText(
        'r_genero',
        getVal('f_genero').toUpperCase()
    );

    setText(
        'r_nacionalidad',
        getVal('f_nacionalidad').toUpperCase()
    );

    setText(
        'r_fecha_nac',
        formatDate('f_fecha_nac')
    );

    setText(
        'r_lugar_nac',
        getVal('f_lugar_nac').toUpperCase()
    );


    // ==========================================
    // VUELTO DEL CARNET
    // ==========================================

    setText(
        'r_direccion',
        getVal('f_direccion').toUpperCase()
    );

    setText(
        'r_tramite',
        getVal('f_tramite').toUpperCase()
    );

    setText(
        'r_madre_v',
        getVal('f_madre').toUpperCase()
    );

    setText(
        'r_padre_v',
        getVal('f_padre').toUpperCase()
    );

    setText(
        'r_color_ojos',
        getVal('f_color_ojos').toUpperCase()
    );

    setText(
        'r_color_cabello',
        getVal('f_color_cabello').toUpperCase()
    );

    setText(
        'r_color_piel',
        getVal('f_color_piel').toUpperCase()
    );

    setText(
        'r_senales',
        getVal('f_senales').toUpperCase()
    );

    setText(
        'r_centro_estudio',
        getVal('f_centro_estudio').toUpperCase()
    );


    // ==========================================
    // FECHAS Y SERIE
    // ==========================================

    setText(
        'r_fecha_venc_v',
        formatDate('f_fecha_venc')
    );

    setText(
        'r_fecha_emision_v',
        formatDate('f_fecha_emision')
    );

    setText(
        'r_serie_mh_v',
        getVal('f_serie_mh').toUpperCase()
    );


    // ==========================================
    // CARTA DE AUTORIZACIÓN
    // ==========================================

    const nombreCompleto =
        `${getVal('f_nombres')} ${getVal('f_apellidos')}`;

    setText(
        'carta_nombre_completo',
        nombreCompleto.toUpperCase()
    );

    setText(
        'carta_fecha_nac',
        formatDate('f_fecha_nac')
    );

    setText(
        'carta_lugar_nac',
        getVal('f_lugar_nac').toUpperCase()
    );

    setText(
        'carta_direccion',
        getVal('f_direccion').toUpperCase()
    );

    setText(
        'carta_num_carnet',
        getVal('f_carnet_num')
    );


    // Padres para carta
    const padre = getVal('f_padre');
    const madre = getVal('f_madre');

    setText(
        'carta_firma_padre',
        padre !== '---' ? padre.toUpperCase() : ''
    );

    setText(
        'carta_firma_madre',
        madre !== '---' ? madre.toUpperCase() : ''
    );


    // Fecha actual de la carta
    const hoy = new Date();

    const opcionesFecha = {
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    };

    setText(
        'carta_fecha_hoy',
        hoy.toLocaleDateString('es-SV', opcionesFecha)
    );


    // ==========================================
    // CONSERVAR LAS IMÁGENES
    // ==========================================

    if (this.state.images.foto) {

        const fotoFrente =
            document.getElementById('render_foto');

        const fotoVuelto =
            document.getElementById('render_foto_v');

        if (fotoFrente) {
            fotoFrente.src = this.state.images.foto;
        }

        if (fotoVuelto) {
            fotoVuelto.src = this.state.images.foto;
        }
    }


    if (this.state.images.firma) {

        const firma =
            document.getElementById('render_firma_menor_v');

        if (firma) {
            firma.src = this.state.images.firma;
            firma.classList.remove('hidden');
        }
    }


    if (this.state.images.huella) {

        const huella =
            document.getElementById('render_huella_v');

        if (huella) {
            huella.src = this.state.images.huella;
            huella.classList.remove('hidden');
        }
    }


    // ==========================================
    // IR A PREVISUALIZACIÓN
    // ==========================================

    this.changeView('preview-carnet');
},

            clearForm: function() {
                if(confirm('¿Está seguro de borrar todo el formulario?')) {
                    document.getElementById('main-form').reset();
                    this.setDefaultDates();
                    ['foto', 'firma', 'huella'].forEach(type => {
                        this.state.images[type] = null;
                        document.getElementById(`preview_img_${type}`).classList.add('hidden');
                        document.getElementById(`icon_${type}`).classList.remove('hidden');
                        
                        const defaultSrc = type === 'huella' ? 'https://placehold.co/100x100/ffffff/00aaff?text=HUELLA' : 
                            (type === 'foto' ? 'https://placehold.co/100x130/e2e8f0/94a3b8?text=FOTO' : 'https://placehold.co/100x40/ffffff/000000?text=Firma');
                            
                        document.getElementById(`render_${type}`).src = defaultSrc;
                        if(type === 'firma') document.getElementById('render_firma_menor').classList.add('hidden');
                        
                        // Reset Vuelto images
                        if(document.getElementById(`render_${type}_v`)) {
                            document.getElementById(`render_${type}_v`).src = defaultSrc;
                            if(type === 'firma') document.getElementById(`render_${type}_v`).classList.add('hidden');
                        }
                    });
                }
            }
        };

        window.onload = function() {
            app.init();
        };